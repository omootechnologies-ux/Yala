import { createAppointment } from "@/app/dashboard/actions";

export function BookAppointmentForm({ leadId }: { leadId: string }) {
  return (
    <form action={createAppointment} className="status-form">
      <input type="hidden" name="lead_id" value={leadId} />
      <input name="scheduled_at" type="datetime-local" required aria-label="Appointment date and time" style={{minHeight: 38, border: '1px solid var(--line)', borderRadius: 10, padding: '6px 8px'}} />
      <button className="btn" type="submit" style={{minHeight: 38, padding: '7px 10px'}}>Book</button>
    </form>
  );
}

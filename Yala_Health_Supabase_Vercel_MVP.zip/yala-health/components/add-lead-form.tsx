import { addLead } from "@/app/dashboard/actions";

function today() {
  return new Date().toISOString().slice(0, 10);
}

export function AddLeadForm() {
  return (
    <div className="card section-space">
      <div className="card-head">
        <div><h2>Add patient enquiry</h2><span className="muted">Capture the lead before it gets forgotten.</span></div>
        <span className="badge">Yala Leads</span>
      </div>
      <form action={addLead} className="form-grid">
        <div className="field"><label htmlFor="patient_name">Patient name</label><input id="patient_name" name="patient_name" required placeholder="Asha M." /></div>
        <div className="field"><label htmlFor="phone">Phone number</label><input id="phone" name="phone" required placeholder="07xx xxx xxx" /></div>
        <div className="field"><label htmlFor="service">Service interested in</label><input id="service" name="service" placeholder="Braces, consultation, cleaning..." /></div>
        <div className="field"><label htmlFor="source">Lead source</label><select id="source" name="source" defaultValue="WhatsApp"><option>WhatsApp</option><option>Google</option><option>Website</option><option>Instagram</option><option>Phone call</option><option>Walk-in</option></select></div>
        <div className="field"><label htmlFor="follow_up_date">Follow-up date</label><input id="follow_up_date" name="follow_up_date" type="date" defaultValue={today()} /></div>
        <div className="field full"><label htmlFor="notes">Notes</label><textarea id="notes" name="notes" placeholder="What did the patient ask about?" /></div>
        <div className="field full"><button className="btn" type="submit">Save enquiry</button></div>
      </form>
    </div>
  );
}

-- Yala Health MVP schema
-- Run this entire file in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.clinics (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null unique references auth.users(id) on delete cascade,
  name text not null,
  phone text,
  city text,
  plan text not null default 'Starter',
  created_at timestamptz not null default now()
);

create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  patient_name text not null,
  phone text not null,
  service text,
  source text not null default 'WhatsApp' check (source in ('WhatsApp','Google','Website','Instagram','Phone call','Walk-in','Other')),
  status text not null default 'New' check (status in ('New','Contacted','Booked','Visited','Review Due','Closed')),
  follow_up_date date,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.appointments (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  scheduled_at timestamptz not null,
  status text not null default 'Scheduled' check (status in ('Scheduled','Completed','Cancelled','No-show')),
  created_at timestamptz not null default now()
);

create table if not exists public.review_requests (
  id uuid primary key default gen_random_uuid(),
  clinic_id uuid not null references public.clinics(id) on delete cascade,
  lead_id uuid not null references public.leads(id) on delete cascade,
  status text not null default 'Due' check (status in ('Due','Sent','Reviewed','Skipped')),
  sent_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists leads_clinic_id_idx on public.leads(clinic_id);
create index if not exists leads_follow_up_idx on public.leads(clinic_id, follow_up_date);
create index if not exists appointments_clinic_idx on public.appointments(clinic_id, scheduled_at);
create index if not exists reviews_clinic_idx on public.review_requests(clinic_id, status);

create or replace function public.set_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists leads_set_updated_at on public.leads;
create trigger leads_set_updated_at before update on public.leads
for each row execute procedure public.set_updated_at();

alter table public.clinics enable row level security;
alter table public.leads enable row level security;
alter table public.appointments enable row level security;
alter table public.review_requests enable row level security;

-- Clinic owner can access only their own clinic.
drop policy if exists "clinic owner select" on public.clinics;
create policy "clinic owner select" on public.clinics for select to authenticated using (owner_id = auth.uid());
drop policy if exists "clinic owner insert" on public.clinics;
create policy "clinic owner insert" on public.clinics for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "clinic owner update" on public.clinics;
create policy "clinic owner update" on public.clinics for update to authenticated using (owner_id = auth.uid()) with check (owner_id = auth.uid());

-- Leads belong to a clinic owned by the logged-in user.
drop policy if exists "owner manages leads" on public.leads;
create policy "owner manages leads" on public.leads for all to authenticated
using (exists (select 1 from public.clinics c where c.id = leads.clinic_id and c.owner_id = auth.uid()))
with check (exists (select 1 from public.clinics c where c.id = leads.clinic_id and c.owner_id = auth.uid()));

-- Appointments are also clinic-isolated.
drop policy if exists "owner manages appointments" on public.appointments;
create policy "owner manages appointments" on public.appointments for all to authenticated
using (exists (select 1 from public.clinics c where c.id = appointments.clinic_id and c.owner_id = auth.uid()))
with check (exists (select 1 from public.clinics c where c.id = appointments.clinic_id and c.owner_id = auth.uid()));

-- Review requests are clinic-isolated.
drop policy if exists "owner manages review requests" on public.review_requests;
create policy "owner manages review requests" on public.review_requests for all to authenticated
using (exists (select 1 from public.clinics c where c.id = review_requests.clinic_id and c.owner_id = auth.uid()))
with check (exists (select 1 from public.clinics c where c.id = review_requests.clinic_id and c.owner_id = auth.uid()));

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createClinic } from "./actions";

export default async function OnboardingPage({ searchParams }: { searchParams: Promise<{ error?: string }> }) {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  if (!claimsData?.claims?.sub) redirect("/login");
  const params = await searchParams;

  return (
    <main className="auth-wrap">
      <section className="auth-card">
        <div className="brand"><span className="brand-mark">Y</span> Yala Health</div>
        <h1>Create your clinic workspace</h1>
        <p className="muted">Each clinic gets a private workspace protected by Supabase Row Level Security.</p>
        {params.error && <div className="notice error">{params.error}</div>}
        <form action={createClinic}>
          <div className="field"><label htmlFor="name">Clinic name</label><input id="name" name="name" required placeholder="e.g. Smile Dental Clinic" /></div>
          <div className="field"><label htmlFor="phone">Clinic phone</label><input id="phone" name="phone" placeholder="+255 ..." /></div>
          <div className="field"><label htmlFor="city">City</label><input id="city" name="city" defaultValue="Dar es Salaam" /></div>
          <button className="btn" type="submit">Create workspace</button>
        </form>
      </section>
    </main>
  );
}

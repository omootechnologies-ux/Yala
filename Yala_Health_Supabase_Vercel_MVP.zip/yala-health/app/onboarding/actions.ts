"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export async function createClinic(formData: FormData) {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect("/login");

  const name = String(formData.get("name") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const city = String(formData.get("city") || "").trim();
  if (!name) redirect("/onboarding?error=Clinic%20name%20is%20required");

  const { error } = await supabase.from("clinics").insert({
    owner_id: userId,
    name,
    phone: phone || null,
    city: city || null,
  });

  if (error) redirect(`/onboarding?error=${encodeURIComponent(error.message.slice(0, 160))}`);
  redirect("/dashboard");
}

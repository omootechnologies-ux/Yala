import { login, signup } from "./actions";

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; message?: string }>;
}) {
  const params = await searchParams;

  return (
    <main className="auth-wrap">
      <section className="auth-card">
        <div className="brand"><span className="brand-mark">Y</span> Yala Health</div>
        <h1>Clinic growth starts here.</h1>
        <p className="muted">Track patient enquiries, bookings, follow-ups and reviews.</p>
        {params.error && <div className="notice error">{params.error}</div>}
        {params.message && <div className="notice success">{params.message}</div>}
        <form>
          <div className="field">
            <label htmlFor="email">Work email</label>
            <input id="email" name="email" type="email" required placeholder="clinic@example.com" />
          </div>
          <div className="field">
            <label htmlFor="password">Password</label>
            <input id="password" name="password" type="password" required minLength={6} placeholder="At least 6 characters" />
          </div>
          <div className="auth-actions">
            <button className="btn" formAction={login}>Sign in</button>
            <button className="btn secondary" formAction={signup}>Create clinic account</button>
          </div>
        </form>
      </section>
    </main>
  );
}

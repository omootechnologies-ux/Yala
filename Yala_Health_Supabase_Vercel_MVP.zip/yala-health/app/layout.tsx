import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Yala Health",
  description: "Patient growth and retention software for clinics",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

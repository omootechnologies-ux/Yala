"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

async function currentClinicId() {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect("/login");

  const { data: clinic } = await supabase.from("clinics").select("id").eq("owner_id", userId).single();
  if (!clinic) redirect("/onboarding");
  return { supabase, clinicId: clinic.id };
}

export async function addLead(formData: FormData) {
  const { supabase, clinicId } = await currentClinicId();
  const patientName = String(formData.get("patient_name") || "").trim();
  const phone = String(formData.get("phone") || "").trim();
  const service = String(formData.get("service") || "").trim();
  const source = String(formData.get("source") || "WhatsApp");
  const followUpDate = String(formData.get("follow_up_date") || "") || null;
  const notes = String(formData.get("notes") || "").trim() || null;
  if (!patientName || !phone) return;

  await supabase.from("leads").insert({
    clinic_id: clinicId,
    patient_name: patientName,
    phone,
    service: service || null,
    source,
    status: "New",
    follow_up_date: followUpDate,
    notes,
  });
  revalidatePath("/dashboard");
}

export async function updateLeadStatus(formData: FormData) {
  const { supabase, clinicId } = await currentClinicId();
  const leadId = String(formData.get("lead_id") || "");
  const status = String(formData.get("status") || "New");
  if (!leadId) return;

  await supabase.from("leads").update({ status }).eq("id", leadId).eq("clinic_id", clinicId);
  revalidatePath("/dashboard");
}

export async function createAppointment(formData: FormData) {
  const { supabase, clinicId } = await currentClinicId();
  const leadId = String(formData.get("lead_id") || "");
  const scheduledLocal = String(formData.get("scheduled_at") || "");
  if (!leadId || !scheduledLocal) return;

  // MVP launches for Tanzanian clinics (UTC+03:00). Convert the browser's
  // datetime-local value to an explicit offset before storing as timestamptz.
  const scheduledAt = /^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/.test(scheduledLocal)
    ? `${scheduledLocal}:00+03:00`
    : scheduledLocal;

  await supabase.from("appointments").insert({ clinic_id: clinicId, lead_id: leadId, scheduled_at: scheduledAt, status: "Scheduled" });
  await supabase.from("leads").update({ status: "Booked", follow_up_date: null }).eq("id", leadId).eq("clinic_id", clinicId);
  revalidatePath("/dashboard");
}

export async function markVisited(formData: FormData) {
  const { supabase, clinicId } = await currentClinicId();
  const appointmentId = String(formData.get("appointment_id") || "");
  const leadId = String(formData.get("lead_id") || "");
  if (!appointmentId || !leadId) return;

  await supabase.from("appointments").update({ status: "Completed" }).eq("id", appointmentId).eq("clinic_id", clinicId);
  await supabase.from("leads").update({ status: "Review Due", follow_up_date: new Date().toISOString().slice(0,10) }).eq("id", leadId).eq("clinic_id", clinicId);
  await supabase.from("review_requests").insert({ clinic_id: clinicId, lead_id: leadId, status: "Due" });
  revalidatePath("/dashboard");
}

export async function markReviewSent(formData: FormData) {
  const { supabase, clinicId } = await currentClinicId();
  const leadId = String(formData.get("lead_id") || "");
  if (!leadId) return;

  await supabase.from("review_requests").update({ status: "Sent", sent_at: new Date().toISOString() }).eq("lead_id", leadId).eq("clinic_id", clinicId).eq("status", "Due");
  await supabase.from("leads").update({ status: "Closed", follow_up_date: null }).eq("id", leadId).eq("clinic_id", clinicId);
  revalidatePath("/dashboard");
}

export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/login");
}

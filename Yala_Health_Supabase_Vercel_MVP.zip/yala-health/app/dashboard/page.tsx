import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { AddLeadForm } from "@/components/add-lead-form";
import { BookAppointmentForm } from "@/components/book-appointment-form";
import { markReviewSent, markVisited, signOut, updateLeadStatus } from "./actions";

const STATUSES = ["New", "Contacted", "Booked", "Visited", "Review Due", "Closed"];

function dateLabel(value: string | null) {
  if (!value) return "—";
  const d = new Date(value.length === 10 ? `${value}T00:00:00Z` : value);
  return new Intl.DateTimeFormat("en", { day: "numeric", month: "short", year: "numeric", timeZone: "Africa/Dar_es_Salaam" }).format(d);
}

function dateTimeLabel(value: string | null) {
  if (!value) return "—";
  return new Intl.DateTimeFormat("en", {
    day: "numeric", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit",
    timeZone: "Africa/Dar_es_Salaam"
  }).format(new Date(value));
}

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();
  const userId = claimsData?.claims?.sub;
  if (!userId) redirect("/login");

  const { data: clinic } = await supabase.from("clinics").select("id,name,city,plan").eq("owner_id", userId).single();
  if (!clinic) redirect("/onboarding");

  const [{ data: leads = [] }, { data: appointments = [] }, { data: reviewRequests = [] }] = await Promise.all([
    supabase.from("leads").select("*").eq("clinic_id", clinic.id).order("created_at", { ascending: false }),
    supabase.from("appointments").select("*, leads(patient_name,phone,service)").eq("clinic_id", clinic.id).order("scheduled_at", { ascending: true }),
    supabase.from("review_requests").select("*").eq("clinic_id", clinic.id),
  ]);

  const today = new Date().toISOString().slice(0, 10);
  const newCount = leads.filter((x) => x.status === "New").length;
  const bookedCount = leads.filter((x) => x.status === "Booked").length;
  const followCount = leads.filter((x) => x.follow_up_date && x.follow_up_date <= today && !["Closed", "Booked"].includes(x.status)).length;
  const reviewCount = reviewRequests.filter((x) => x.status === "Due").length;
  const maxPipeline = Math.max(1, ...STATUSES.map((s) => leads.filter((x) => x.status === s).length));
  const scheduled = appointments.filter((x) => x.status === "Scheduled");

  return (
    <div className="shell">
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand"><span className="brand-mark">Y</span><div>Yala Health <span className="muted" style={{fontWeight: 500}}>· {clinic.name}</span></div></div>
          <form action={signOut}><button className="btn secondary" type="submit">Sign out</button></form>
        </div>
      </header>

      <main className="container">
        <section className="hero">
          <div><span className="badge">Patient Growth OS</span><h1>Never lose a patient enquiry.</h1><p>From first WhatsApp or Google enquiry to appointment, follow-up and review.</p></div>
          <div className="badge gray">Plan: {clinic.plan}</div>
        </section>

        <section className="grid metrics">
          <div className="metric"><div className="metric-label">New enquiries</div><div className="metric-value">{newCount}</div></div>
          <div className="metric"><div className="metric-label">Booked</div><div className="metric-value">{bookedCount}</div></div>
          <div className="metric"><div className="metric-label">Need follow-up</div><div className="metric-value">{followCount}</div></div>
          <div className="metric"><div className="metric-label">Reviews due</div><div className="metric-value">{reviewCount}</div></div>
        </section>

        <section className="grid main-grid">
          <div className="card">
            <div className="card-head"><div><h2>Patient pipeline</h2><span className="muted">See exactly where enquiries are getting stuck.</span></div></div>
            <div className="pipeline">
              {STATUSES.slice(0,5).map((status) => {
                const count = leads.filter((x) => x.status === status).length;
                return <div className="pipe-row" key={status}><span>{status}</span><div className="pipe-track"><div className="pipe-fill" style={{width: `${Math.max(count ? 8 : 0, (count/maxPipeline)*100)}%`}} /></div><strong>{count}</strong></div>;
              })}
            </div>
          </div>
          <div className="card">
            <h2>Today&apos;s priorities</h2>
            <div className="priority"><strong>{followCount}</strong> patient enquiries need follow-up.</div>
            <div className="priority"><strong>{scheduled.length}</strong> upcoming scheduled appointments.</div>
            <div className="priority"><strong>{reviewCount}</strong> patient review requests are due.</div>
          </div>
        </section>

        <AddLeadForm />

        <section className="card section-space">
          <div className="card-head"><div><h2>Enquiries</h2><span className="muted">Receptionists update the status as each patient moves forward.</span></div><span className="badge">{leads.length} total</span></div>
          <div className="table-wrap">
            <table>
              <thead><tr><th>Patient</th><th>Interest</th><th>Source</th><th>Follow-up</th><th>Status</th><th>Appointment</th></tr></thead>
              <tbody>
                {leads.length === 0 ? <tr><td colSpan={6} className="empty">No enquiries yet. Add the first one above.</td></tr> : leads.map((lead) => (
                  <tr key={lead.id}>
                    <td><strong>{lead.patient_name}</strong><br/><span className="muted">{lead.phone}</span></td>
                    <td>{lead.service || "—"}</td>
                    <td><span className="badge gray">{lead.source}</span></td>
                    <td>{dateLabel(lead.follow_up_date)}</td>
                    <td>
                      <form action={updateLeadStatus} className="status-form">
                        <input type="hidden" name="lead_id" value={lead.id} />
                        <select name="status" defaultValue={lead.status}>{STATUSES.map((s) => <option key={s}>{s}</option>)}</select>
                        <button className="btn secondary" type="submit" style={{minHeight:38,padding:'7px 9px'}}>Save</button>
                      </form>
                    </td>
                    <td>{lead.status === "Review Due" ? (
                      <form action={markReviewSent}><input type="hidden" name="lead_id" value={lead.id}/><button className="btn" type="submit">Review sent</button></form>
                    ) : lead.status !== "Booked" && lead.status !== "Closed" ? <BookAppointmentForm leadId={lead.id} /> : <span className="muted">{lead.status === "Booked" ? "Booked" : "—"}</span>}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>

        <section className="grid main-grid section-space">
          <div className="card">
            <div className="card-head"><div><h2>Appointments</h2><span className="muted">Upcoming booked patient visits.</span></div></div>
            <div className="list">
              {scheduled.length === 0 ? <div className="empty">No scheduled appointments.</div> : scheduled.map((appointment) => {
                const lead = Array.isArray(appointment.leads) ? appointment.leads[0] : appointment.leads;
                return <div className="list-item" key={appointment.id}><div><strong>{lead?.patient_name || "Patient"}</strong><small>{lead?.service || "Consultation"} · {dateTimeLabel(appointment.scheduled_at)}</small></div><form action={markVisited}><input type="hidden" name="appointment_id" value={appointment.id}/><input type="hidden" name="lead_id" value={appointment.lead_id}/><button className="btn secondary" type="submit">Mark visited</button></form></div>;
              })}
            </div>
          </div>
          <div className="card">
            <div className="card-head"><div><h2>Review queue</h2><span className="muted">Turn completed visits into patient trust.</span></div></div>
            <div className="list">
              {reviewRequests.filter((r) => r.status === "Due").length === 0 ? <div className="empty">No review requests due.</div> : reviewRequests.filter((r) => r.status === "Due").map((r) => {
                const lead = leads.find((x) => x.id === r.lead_id);
                return <div className="list-item" key={r.id}><div><strong>{lead?.patient_name || "Patient"}</strong><small>Send Google review link after the visit.</small></div><form action={markReviewSent}><input type="hidden" name="lead_id" value={r.lead_id}/><button className="btn" type="submit">Mark sent</button></form></div>;
              })}
            </div>
          </div>
        </section>

        <p className="footer-note">MVP scope: lead conversion, appointments, follow-up and review workflow. Clinical records, prescriptions and diagnosis are intentionally excluded.</p>
      </main>
    </div>
  );
}

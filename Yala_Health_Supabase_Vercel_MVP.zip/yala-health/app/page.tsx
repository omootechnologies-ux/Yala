import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";

export default async function Home() {
  const supabase = await createClient();
  const { data: claimsData } = await supabase.auth.getClaims();

  if (!claimsData?.claims?.sub) redirect("/login");

  const { data: clinic } = await supabase
    .from("clinics")
    .select("id")
    .eq("owner_id", claimsData.claims.sub)
    .maybeSingle();

  redirect(clinic ? "/dashboard" : "/onboarding");
}

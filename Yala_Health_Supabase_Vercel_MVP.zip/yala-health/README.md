# Yala Health MVP

A deployable B2B SaaS starter for clinics: patient enquiries -> follow-up -> appointment -> visit -> review.

## Stack
- Next.js App Router
- Supabase Auth + Postgres + Row Level Security
- Vercel deployment

## 1. Create Supabase
1. Create a new Supabase project.
2. Open **SQL Editor**.
3. Paste and run `supabase/migrations/001_yala_health.sql`.
4. In **Project Settings / API** (or the Connect dialog), copy:
   - Project URL
   - Publishable key

## 2. Configure local environment
Copy `.env.example` to `.env.local` and set:

```env
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=sb_publishable_YOUR_KEY
NEXT_PUBLIC_SITE_URL=http://localhost:3000
```

## 3. Supabase Auth URLs
In Supabase Auth URL configuration:
- Site URL (local): `http://localhost:3000`
- Redirect URL: `http://localhost:3000/auth/callback`

When deployed, also add:
- `https://YOUR-VERCEL-DOMAIN.vercel.app/auth/callback`
- or your final custom Yala domain callback.

## 4. Run locally
```bash
npm install
npm run dev
```
Open `http://localhost:3000`.

## 5. Deploy to Vercel
1. Put this folder in a GitHub repository.
2. Import the repo into Vercel.
3. Add these Vercel Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`
   - `NEXT_PUBLIC_SITE_URL=https://YOUR-VERCEL-DOMAIN.vercel.app`
4. Deploy.
5. Add your production callback URL in Supabase Auth settings.
6. Redeploy if you changed environment variables.

## Timezone
The MVP assumes Tanzanian clinic appointment entry in **Africa/Dar_es_Salaam (UTC+03:00)** and stores appointments as `timestamptz`. If Yala expands internationally, replace this fixed launch assumption with a per-clinic timezone setting.

## MVP features
- Email/password clinic signup and login
- Clinic onboarding
- Private clinic workspace
- Patient enquiry capture
- Lead pipeline statuses
- Follow-up dates
- Appointment booking
- Mark visit completed
- Review-request queue
- Dashboard metrics
- Supabase Row Level Security so each clinic sees only its own records

## Important scope choice
This MVP intentionally avoids medical records, diagnosis, prescriptions, lab results and clinical notes. It is a patient-growth/retention product, not an EMR/HMS.

## Suggested next features
1. Staff accounts per clinic
2. WhatsApp Business API integration
3. Automated appointment reminders
4. Website lead form webhook/API
5. Google review link per clinic
6. Subscription billing
7. Multi-branch clinics
8. Audit log and permissions
